import TelaFutebol from "../components/TelaFutebol";

export default function Futebol(){
    return(
        <TelaFutebol />
    )
}