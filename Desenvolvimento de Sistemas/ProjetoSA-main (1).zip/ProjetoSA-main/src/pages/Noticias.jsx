import React from 'react';
import { useNavigate } from 'react-router-dom';
import TLogin from '../components/TelaLogin';
import NoticiasPage from '../components/TelaNoticias';

export default function Noticias () {
return(
    <>
    <NoticiasPage />
    </>
)
}