import React from 'react';
import { useNavigate } from 'react-router-dom';
import TelaEsportes from '../components/TelaEsportes';

export default function Esportes() {
    return(
        <>
        <TelaEsportes />
        </>
    )
}