import React from "react";
import TelaCadastro from "../components/TelaCadastro";

export default function Cadastro(){
    return(
        <>
        <TelaCadastro/>
        </>
    )
}