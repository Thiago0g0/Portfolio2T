import React from "react";
import TelaConfig from "../components/TelaConfig";

export default function Configuracoes(){
    return(
        <>
        <TelaConfig/>
        </>
    )
}