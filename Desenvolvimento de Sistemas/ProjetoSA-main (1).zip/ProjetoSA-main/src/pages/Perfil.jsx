import React from 'react';
import { useNavigate } from 'react-router-dom';
import TelaPerfil from '../components/TelaPerfil';

export default function Perfil () {

  return (
    <>
    <TelaPerfil />
    </>
  ) 
}

  