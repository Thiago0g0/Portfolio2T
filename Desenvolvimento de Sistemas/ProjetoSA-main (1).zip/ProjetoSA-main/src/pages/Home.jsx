import React from 'react';
import { useNavigate } from 'react-router-dom';
import TelaHome from '../components/TelaHome';

export default function Home() {
  return (
    <>
      <TelaHome />
    </>
  );
}