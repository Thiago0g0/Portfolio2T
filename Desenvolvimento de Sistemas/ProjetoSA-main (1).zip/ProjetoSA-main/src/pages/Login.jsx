import React from 'react';
import { useNavigate } from 'react-router-dom';
import TLogin from '../components/TelaLogin';

export default function Login () {
return(
    <>
    <TLogin />
    </>
)
}