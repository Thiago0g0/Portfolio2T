import React from "react";
import TRelatorio from "../components/TelaRelatorio";

export default function Relatorio(){
    return(
        <>
        <TRelatorio />
        </>
    )
}