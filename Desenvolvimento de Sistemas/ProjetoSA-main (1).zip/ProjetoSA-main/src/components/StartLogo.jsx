export default function LogoStart(){
    return(
        <div>
            <header>
                <img src="logoss.jpg" />
            </header>
        </div>
    )
}