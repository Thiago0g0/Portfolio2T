export default function Button({titulo}) {
    return (
        <>
        <button>{titulo}</button>
        </>
    )
}