import Container from "../components/layout/Container"

export default function Regras() {
    return(
        <Container >
        <h1>regras</h1>
        </Container>
    )   
}