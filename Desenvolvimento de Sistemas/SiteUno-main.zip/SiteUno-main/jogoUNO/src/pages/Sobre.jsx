import Container from "../components/layout/Container"

export default function Sobre() {
    return(
        <Container >
            <h1>sobre</h1>
        </Container>
    )
}