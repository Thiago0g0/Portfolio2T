import Container from "../components/layout/Container";


export default function Ajuda() {
    return(
        <>
        <Container >
            <h1>ajuda</h1>
       </Container>
        </>
    )
}