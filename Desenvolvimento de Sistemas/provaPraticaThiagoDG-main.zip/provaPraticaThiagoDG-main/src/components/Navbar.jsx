export default function Navbar() {
    return (
        <div>
            <nav className="nav">
                <div className="navnam">
                    <h4 className="name">Thiago Domingos - 3B</h4>
                    <img src="sesi.jpg" alt="" />
                </div>
            </nav>
        </div>
    )
}