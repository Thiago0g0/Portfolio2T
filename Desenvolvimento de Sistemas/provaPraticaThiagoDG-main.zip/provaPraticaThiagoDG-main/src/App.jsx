import './App.css'
import Navbar from './components/Navbar'
import Times from'./components/Times'

function App() {

  return (
    <>
      <Navbar />
      <Times />
      
    </>
  )
}

export default App
